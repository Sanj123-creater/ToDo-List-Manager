# CLI To-Do List Manager

## Overview
A beginner-friendly command-line To-Do List Manager written in Python using only the standard library. Users can add tasks, view tasks and completion status, mark tasks completed, remove tasks, and exit. Tasks are saved to `tasks.json` so they remain available after restarting the program.

## Requirements
- Python 3.10 or newer
- No third-party packages required

## How to run
1. Extract the ZIP file.
2. Open a terminal in the `todo_cli_submission` folder.
3. Run:

   ```bash
   python main.py
   ```

The program creates `tasks.json` when tasks are first saved.

## How to run tests
From the project folder, run:

```bash
python -m unittest discover -s tests -v
```

## Architecture
- `main.py`: displays the menu, collects input, handles user-facing errors, and connects the other modules.
- `todo.py`: contains the core task operations (`add_task`, `view_tasks`, `mark_completed`, and `remove_task`).
- `storage.py`: loads and saves tasks in JSON format.
- `tests/test_todo.py`: automated tests for core operations and persistence.
- `tasks.json`: created automatically at runtime to persist tasks.

## Data structure
Each task is a dictionary:
```python
{"title": "Study Python", "completed": False}
```
All tasks are stored in a list of dictionaries.

## Pseudocode
1. Load tasks from the JSON file.
2. Repeatedly display the menu until the user chooses Exit.
3. Validate the menu choice.
4. For Add: request a title, reject blank titles, add a task, and save.
5. For View: display a message if the list is empty; otherwise display each task and its status.
6. For Complete: validate the task number, update its status, and save.
7. For Remove: validate the task number, remove it, and save.
8. For Exit: stop the loop.
9. Handle invalid numeric input without crashing.

## Design choices and error handling
- Core task logic is separated from menu/input code to make it easier to maintain and test.
- JSON is used because it is human-readable and included in Python's standard library.
- Task numbers shown to the user start at 1; Python list indexes start at 0, so the implementation subtracts 1 after validation.
- Blank task titles and invalid task numbers are rejected.
- Non-numeric menu/task input is caught and reported rather than crashing.
- An empty task list displays `No tasks available.`

## Manual test scenarios
| Scenario | Action | Expected result |
|---|---|---|
| Add a task | Choose 1 and enter `Study Python` | Task added successfully |
| Blank task | Choose 1 and press Enter | Blank title rejected |
| View empty list | Choose 2 with no saved tasks | `No tasks available.` |
| View tasks | Add two tasks, choose 2 | Both tasks and statuses shown |
| Mark complete | Choose 3 and enter a valid task number | Status changes to Completed |
| Invalid task number | Choose 3 or 4 and enter 0 or an out-of-range number | Helpful error message |
| Non-numeric input | Enter `hello` at menu/task number prompt | Program does not crash |
| Remove task | Choose 4 and enter a valid task number | Task removed |
| Persistence | Add a task, exit, run again, choose 2 | Saved task still appears |
| Exit | Choose 5 | Program exits cleanly |

## Future improvements
Possible extensions include task editing, due dates, priorities, and a graphical interface.
