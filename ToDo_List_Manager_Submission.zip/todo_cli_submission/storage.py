"""JSON persistence for the To-Do List Manager."""
import json
from pathlib import Path

TASKS_FILE = Path(__file__).with_name("tasks.json")


def load_tasks(file_path=TASKS_FILE):
    """Load saved tasks; return an empty list when no save file exists."""
    path = Path(file_path)
    if not path.exists():
        return []
    try:
        with path.open("r", encoding="utf-8") as file:
            data = json.load(file)
        if not isinstance(data, list):
            raise ValueError("Saved task data must be a list.")
        return data
    except (json.JSONDecodeError, OSError) as error:
        raise RuntimeError(f"Could not load saved tasks: {error}") from error


def save_tasks(tasks, file_path=TASKS_FILE):
    """Save tasks to a JSON file."""
    path = Path(file_path)
    try:
        with path.open("w", encoding="utf-8") as file:
            json.dump(tasks, file, indent=4, ensure_ascii=False)
    except OSError as error:
        raise RuntimeError(f"Could not save tasks: {error}") from error
