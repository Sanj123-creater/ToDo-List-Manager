"""Unit tests for task operations and JSON storage."""
import json
import tempfile
import unittest
from pathlib import Path

from todo import add_task, view_tasks, mark_completed, remove_task
from storage import load_tasks, save_tasks


class TodoTests(unittest.TestCase):
    def setUp(self):
        self.tasks = []

    def test_add_task(self):
        add_task(self.tasks, "Study Python")
        self.assertEqual(self.tasks, [{"title": "Study Python", "completed": False}])

    def test_reject_empty_task(self):
        with self.assertRaises(ValueError):
            add_task(self.tasks, "   ")

    def test_view_empty_tasks(self):
        self.assertEqual(view_tasks(self.tasks), "No tasks available.")

    def test_view_task_status(self):
        add_task(self.tasks, "Study Python")
        self.assertIn("1. Study Python - Not Completed", view_tasks(self.tasks))
        mark_completed(self.tasks, 1)
        self.assertIn("1. Study Python - Completed", view_tasks(self.tasks))

    def test_invalid_task_number(self):
        with self.assertRaises(IndexError):
            mark_completed(self.tasks, 1)

    def test_remove_task(self):
        add_task(self.tasks, "A")
        removed = remove_task(self.tasks, 1)
        self.assertEqual(removed["title"], "A")
        self.assertEqual(self.tasks, [])

    def test_save_and_load(self):
        add_task(self.tasks, "Persist me")
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "tasks.json"
            save_tasks(self.tasks, path)
            self.assertEqual(load_tasks(path), self.tasks)


if __name__ == "__main__":
    unittest.main()
