"""Command-line interface for the To-Do List Manager."""
from storage import load_tasks, save_tasks
from todo import add_task, view_tasks, mark_completed, remove_task


def get_integer(prompt):
    """Read an integer safely; return None when the input is not an integer."""
    try:
        return int(input(prompt).strip())
    except ValueError:
        print("Please enter a valid number.")
        return None


def main():
    tasks = load_tasks()

    while True:
        print("\n======= TO-DO LIST =======")
        print("1. Add Task")
        print("2. View Tasks")
        print("3. Mark Task as Completed")
        print("4. Remove Task")
        print("5. Exit")

        choice = get_integer("Enter your choice: ")
        if choice is None:
            continue

        if choice == 1:
            title = input("Enter task: ")
            try:
                add_task(tasks, title)
                save_tasks(tasks)
                print("Task added successfully.")
            except ValueError as error:
                print(error)

        elif choice == 2:
            print("\n" + view_tasks(tasks))

        elif choice == 3:
            if not tasks:
                print("No tasks available.")
                continue
            number = get_integer("Enter the task number to complete: ")
            if number is None:
                continue
            try:
                mark_completed(tasks, number)
                save_tasks(tasks)
                print("Task marked as completed.")
            except (ValueError, IndexError) as error:
                print(error)

        elif choice == 4:
            if not tasks:
                print("No tasks available.")
                continue
            number = get_integer("Enter the task number to remove: ")
            if number is None:
                continue
            try:
                removed = remove_task(tasks, number)
                save_tasks(tasks)
                print(f"Removed task: {removed['title']}")
            except (ValueError, IndexError) as error:
                print(error)

        elif choice == 5:
            print("Goodbye!")
            break

        else:
            print("Invalid choice. Enter a number from 1 to 5.")


if __name__ == "__main__":
    main()
