"""Core task operations, separated from the user interface."""


def add_task(tasks, title):
    """Add a task with a title and an initially incomplete status."""
    title = title.strip()
    if not title:
        raise ValueError("Task title cannot be empty.")
    tasks.append({"title": title, "completed": False})


def view_tasks(tasks):
    """Return a readable representation of all tasks."""
    if not tasks:
        return "No tasks available."

    lines = ["Your tasks:"]
    for number, task in enumerate(tasks, start=1):
        status = "Completed" if task.get("completed", False) else "Not Completed"
        lines.append(f"{number}. {task['title']} - {status}")
    return "\n".join(lines)


def mark_completed(tasks, task_number):
    """Mark a 1-based task number as completed."""
    index = _validated_index(tasks, task_number)
    tasks[index]["completed"] = True


def remove_task(tasks, task_number):
    """Remove and return a task using its 1-based task number."""
    index = _validated_index(tasks, task_number)
    return tasks.pop(index)


def _validated_index(tasks, task_number):
    if not isinstance(task_number, int):
        raise ValueError("Task number must be an integer.")
    if task_number < 1 or task_number > len(tasks):
        raise IndexError(f"Task number must be between 1 and {len(tasks)}.")
    return task_number - 1
